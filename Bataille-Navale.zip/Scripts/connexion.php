<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db="jeu";
    // Create connection
    $conn = new mysqli($servername, $username, $password,$db);
?>