<a href="http://localhost/jeu/index.php" class="navBar">
		<img class="logo" alt="..." src="./Assets/logo.ico"/>
		<p class="title">Bataille Navale</p>
</a>